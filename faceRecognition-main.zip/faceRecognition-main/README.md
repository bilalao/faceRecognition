# faceRecognition(OpenCv)

Necessary packages dlib , <i>face_recognition </i>, <br>
I used in this Project dlib library with other Python libraries to do real-time face recognition
